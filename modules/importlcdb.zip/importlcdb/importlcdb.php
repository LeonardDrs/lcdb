<?php

if (!defined('_PS_VERSION_'))
	exit;

class Importlcdb extends Module
{
	public function __construct()
	{
		$this->name = 'importlcdb';
		$this->tab = 'migration_tools';
		$this->version = '2.0';
		$this->author = 'PrestaShop';
		$this->need_instance = 0;

		parent::__construct();

		$this->displayName = $this->l('Import LCDB');
		$this->description = $this->l('Synchronizes previous database of shop');
		$path = dirname(__FILE__);
		if (strpos(__FILE__, 'Module.php') !== false)
			$path .= '/../modules/'.$this->name;
		// include_once $path.'/EditorialClass.php';
	}

	public function install()
	{
		if (!parent::install())
			return false;
	}
	
	public function uninstall()
	{

		if (!parent::uninstall())
			return false;

		return true;
	}

	public function displayForm()
	{
		// Get default Language
		$default_lang = (int)Configuration::get('PS_LANG_DEFAULT');

		// Init Fields form array
		$fields_form[0]['form'] = array(
			'legend' => array(
				'title' => $this->l('Settings'),
			),
			'input' => array(
				array(
					'type' => 'checkbox',
					'label' => $this->l('Tables:'),
					'name' => 'table',
					'values' => array(
						'query' => array(
							array(
								'id' => 0,
								'name' => $this->l('Produits')
							),
							array(
								'id' => 1,
								'name' => $this->l('Categories')
							),
							array(
								'id' => 2,
								'name' => $this->l('Clients')
							),
							array(
								'id' => 3,
								'name' => $this->l('Commandes')
							),
							array(
								'id' => 4,
								'name' => $this->l('Temoignages')
							)
						),
						'id' => 'id',
						'name' => 'name'
					),
					'desc' => $this->l('Base that you want synchronize')
				),
			),
			'submit' => array(
				'title' => $this->l('Save'),
				'class' => 'button'
			)
		);

		$helper = new HelperForm();

		// Module, t    oken and currentIndex
		$helper->module = $this;
		$helper->name_controller = $this->name;
		$helper->token = Tools::getAdminTokenLite('AdminModules');
		$helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;

		// Language
		$helper->default_form_language = $default_lang;
		$helper->allow_employee_form_lang = $default_lang;

		// Title and toolbar
		$helper->title = $this->displayName;
		$helper->show_toolbar = true;        // false -> remove toolbar
		$helper->toolbar_scroll = true;      // yes - > Toolbar is always visible on the top of the screen.
		$helper->submit_action = 'submit'.$this->name;
		$helper->toolbar_btn = array(
			'synchronize' =>
		array(
			'desc' => $this->l('Synchronize'),
			'href' => AdminController::$currentIndex.'&configure='.$this->name.'&save'.$this->name.
			'&token='.Tools::getAdminTokenLite('AdminModules'),
			),
		'back' => array(
			'href' => AdminController::$currentIndex.'&token='.Tools::getAdminTokenLite('AdminModules'),
			'desc' => $this->l('Back to list')
			)
			);

		// Load current value
		$helper->fields_value['MYMODULE_NAME'] = Configuration::get('MYMODULE_NAME');

		return $helper->generateForm($fields_form);
	}

	public function updateCategories()
	{
		$category = new Category();
		// content
		$category->name = "Test de category";
		$category->id_parent = 2;
		$category->link_rewrite = "test-de-category";
		// add
		if (($category->validateFields(false, true)) === true && ($category->validateFieldsLang(false, true)) === true && $category->add()){
			echo "category enregistrée <br/>";
		}
	}
	
	public function updateProducts($row)
	{
		
		// echo "id_produit ".$row->idproduit;
		// echo "<br/>";
		// echo "type ".$row->type;
		// echo "<br/>";
		// echo "libellé ".$row->libelle;
		// echo "<br/>";
		// echo "conditionnement ".$row->conditionnement;
		// echo "<br/>";
		// echo "personnes ".$row->pers;
		// echo "<br/>";
		// echo "frais ".$row->frais;
		// echo "<br/>";
		// echo "bio ? ".$row->bio;
		// echo "<br/>";
		// echo "label rouge ? ".$row->labelrouge;
		// echo "<br/>";
		// echo "prix ".$row->prix;
		// echo "<br/>";
		// echo "tva".$row->tva;
		// echo "<br/>";
		// echo "poids ".$row->poids;
		// echo "<br/>";
		// echo "prix kg ".$row->prixkg;
		// echo "<br/>";
		// echo "ordre ".$row->ordre;
		// echo "<br/>";
		// echo "etat ".$row->etat;
		// echo "<br/>";
		// echo "cible ".$row->cible;
		// echo "<br/>";
		// echo "date limite ".$row->datelimite;
		// echo "<br/>";
		// echo "<br/>";
		
		$sql = 'SELECT p.id_product
				FROM '._DB_PREFIX_.'product p
				WHERE p.id_product = '.(int)$row->idproduit;
				
		$result = Db::getInstance()->getValue($sql);

		if($result !=null){
			echo 'le produit existe <br/>';
		}else{
			$product = new Product();
			$product->addToCategories(array(8));
			$product->id_category_default = 8;
			$product->name = $row->libelle;
			$product->link_rewrite = $this->create_slug($row->libelle);
			// conditionnement
			// personnes
			// frais
			// bio ? 
			// label rouge ?
			$product->price = $row->prix;
			// tva
			// poids
			// prix kg
			// ordre
			if($row->etat == "off"){
				$product->active = 0;
			}
			// cible
			// date limite
			
			if (($product->validateFields(false, true)) === true && ($product->validateFieldsLang(false, true)) === true && $product->add()){
				echo "Produit enregistré <br/>";
			}else{
				echo "erreur pour le produit ".$product->id."<br/>";
			}
			
		}
		
	}
	
	public function updatePosts()
	{
		$post = new Post();
		// content
		$post->title = "Test post";
		$post->content = "Content du post";
		$post->active = 1;
		// add
		if (($post->validateFields(false, true)) === true && ($post->validateFieldsLang(false, true)) === true && $post->add()){
			echo "Post enregistré <br/>";
		}
	}
	
	public function updateOrders()
	{
		$order = new Order();
		// content
		$order->name = "Test de produit";
		$order->id_address_delivery = 2;
		$order->id_address_invoice = 2;
		$order->secure_key = "81cbf1e93f9bbd6c87413fd21822e537";
		$order->id_cart = 2;
		$order->id_currency = 1;
		$order->id_lang = 5;
		$order->id_customer = 2;
		$order->id_carrier = 1;
		$order->payment = "Banane";
		$order->total_paid = 100;
		$order->total_paid_real = 0;
		$order->total_products = 80;
		$order->total_products_wt = 88;
		$order->conversion_rate = 1.0;
		
		// add
		if ($order->add()){
			echo "Commande enregistré <br/>";
		}else{
			echo "erreur";
		}
	}
	
	public function getTable($table)
	{
		
		/** Etape 1 : initialisation de la session **/
		$ch = curl_init() ;
		/** Etape 2 : définition des options **/
		curl_setopt($ch, CURLOPT_URL, 'http://www.lescolisduboucher.com/export/export.php?table='.$table);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		/** Etape 3 : exécution de la requête **/
		$content = curl_exec($ch) ;
		/** Etape 4 : fermeture de la session **/
		curl_close($ch) ;
		/** Etape 4 : renvoi le contenu **/
		return $content;
	}
	
	function create_slug($str){
		$maxlen = 42;  //Modifier la taille max du slug ici
		$slug = strtolower($str);
		$slug = preg_replace("/[^a-z0-9\s-]/", "", $slug);
		$slug = trim(preg_replace("/[\s-]+/", " ", $slug));
		$slug = preg_replace("/\s/", "-", $slug);
		return $slug;
	}

	public function getContent()
	{
		$output = null;
		
		// commandes et associations (paniers, commandes details...)
		// messages
		// temoignages
		// clients et associations (adresses, parrainages, non inscrits ??...)
		// produits et associations ()
		
		if (Tools::isSubmit('submit'.$this->name))
		{
			if($input_product = Tools::getValue('table_0')){
				// $content = json_decode($this->getTable("carte"));
				// 			foreach ($content as $row) {
				// 				$this->updateProducts($row);
				// 			}
				$product = new Product();
				$product->id_product = 699;
				$product->name = "produit test 699";
				$product->link_rewrite = "product-test";

				if (($product->validateFields(false, true)) === true && ($product->validateFieldsLang(false, true)) === true && $product->add()){
					echo "Produit enregistré <br/>";
				}else{
					echo "erreur pour le produit ".$product->id_product."<br/>";
				}
			}
			if($input_category = Tools::getValue('table_1')){
			//	$this->updateCategories();
			}
			if($input_order = Tools::getValue('table_3')){
			//	$this->updateOrders();
			}
			if($input_post = Tools::getValue('table_4')){
			//	$this->updatePosts();
			}
		}
		
		return $output.$this->displayForm();
	}

}
