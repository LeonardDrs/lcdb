<?php

class ImportlcdbClass extends ObjectModel
{
	public function getProduct(){
		
		return 'oui';
	}
}
